#!/usr/bin/env bash
# Build FBNeo Android APK from inside project.zip (run by GitHub Actions)
set -euo pipefail
cd "$(dirname "$0")"

echo "=== Fetching FBNeo ==="
rm -rf fbneo-src
git clone --depth 1 https://github.com/finalburnneo/FBNeo.git fbneo-src
echo "FBNeo commit: $(git -C fbneo-src rev-parse HEAD)"

echo "=== Applying Android patches ==="
python3 - <<'PYEOF'
import sys, pathlib
FB = pathlib.Path("fbneo-src")

def patch_file(rel, subs):
    p = FB / rel
    s = p.read_text()
    for old, new in subs:
        if new in s:
            print("[skip] " + rel + ": already applied")
            continue
        n = s.count(old)
        if n != 1:
            print("[FAIL] " + rel + ": anchor found " + str(n) + "x: " + repr(old[:70]))
            sys.exit(1)
        s = s.replace(old, new)
        print("[ok] " + rel)
    p.write_text(s)

patch_file("src/burner/burner.h", [
    ('#elif defined(BUILD_QT)\n #include "burner_qt.h"\n#endif',
     '#elif defined(BUILD_QT)\n #include "burner_qt.h"\n#elif defined (BUILD_ANDROID)\n #include "burner_android.h"\n#endif'),
])

patch_file("src/intf/video/vid_interface.cpp", [
    ('    extern struct VidOut VidOutOGL;\n#endif',
     '    extern struct VidOut VidOutOGL;\n#elif defined (BUILD_ANDROID)\nextern struct VidOut VidOutAndroid;\n#endif'),
    ('    &VidOutOGL,\n#endif',
     '    &VidOutOGL,\n#elif defined (BUILD_ANDROID)\n\t&VidOutAndroid,\n#endif'),
])

patch_file("src/intf/audio/aud_interface.cpp", [
    ('    extern struct AudOut AudOutQtSound;\n#endif',
     '    extern struct AudOut AudOutQtSound;\n#elif defined (BUILD_ANDROID)\nextern struct AudOut AudOutAndroid;\n#endif'),
    ('    &AudOutQtSound,\n#endif',
     '    &AudOutQtSound,\n#elif defined (BUILD_ANDROID)\n\t&AudOutAndroid,\n#endif'),
])

patch_file("src/intf/input/inp_interface.cpp", [
    ('\textern struct InputInOut InputInOutQt;\n#endif',
     '\textern struct InputInOut InputInOutQt;\n#elif defined (BUILD_ANDROID)\nextern struct InputInOut InputInOutAndroid;\n#endif'),
    ('\t&InputInOutQt,\n#endif',
     '\t&InputInOutQt,\n#elif defined (BUILD_ANDROID)\n\t&InputInOutAndroid,\n#endif'),
])

print("All Android patches applied.")
PYEOF

echo "=== Configuring SDK/NDK ==="
NDK=$(ls -d "$ANDROID_HOME"/ndk/* | sort -V | tail -1)
printf 'sdk.dir=%s\nndk.dir=%s\n' "$ANDROID_HOME" "$NDK" > local.properties
cat local.properties

echo "=== Building APK ==="
FBNEO_DIR="$PWD/fbneo-src" gradle :app:assembleDebug -Dorg.gradle.daemon=false --stacktrace

mkdir -p out
cp app/build/outputs/apk/debug/app-debug.apk out/FBNeo.apk
echo "=== Done: out/FBNeo.apk ==="
