# FBNeo Android (personal, non-commercial port)

A personal Android port of FinalBurn Neo with a custom UI and Lua scripting
(supports Fightcade-style scripts like 3rd_training.lua).

FBNeo license: non-commercial, see src/license.txt in the FBNeo repo.
No ROMs included.

## Repo layout
- blank.yml (in .github/workflows) - GitHub Actions workflow
- project.zip - the whole Android project; replace it and push to rebuild

## Using the app
- Put MAME-style ROM zips in: Android/data/com.fbneo.android/files/roms/
- Put .lua scripts in: Android/data/com.fbneo.android/files/scripts/
